DINDER - Vanainimeste Dinder, suhtlusportaal.


TIIMILIIKMED - Sander-Aleks Mander, Karl-Patric Rohi, Kristo Tänak, Airi Zenkevics, Evert Kärp


FIGMA LINK - https://www.figma.com/file/H50PXyPZjaykELkuT9TuiO/Untitled
